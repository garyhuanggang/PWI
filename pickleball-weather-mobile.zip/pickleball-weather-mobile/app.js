
function fetchWeather() {
  const city = document.getElementById("cityInput").value || "Naperville";
  document.getElementById("hourlyBar").innerHTML = "";
  document.getElementById("detailsCard").innerHTML = "";
  document.getElementById("weeklyForecast").innerHTML = "";

  // Simulated hourly data
  for (let i = 0; i < 24; i++) {
    const box = document.createElement("div");
    box.className = "hour-box";
    box.innerHTML = `<strong>${i}:00</strong><br>☀️<br>${65 + i % 5}°F`;
    box.onclick = () => showDetails(i);
    document.getElementById("hourlyBar").appendChild(box);
  }

  // Simulated 7-day forecast
  const days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  for (let i = 0; i < 7; i++) {
    const card = document.createElement("div");
    card.className = "day-card";
    card.innerHTML = `<strong>${days[(new Date().getDay() + i) % 7]}</strong>: 🌤️ ${70 + i}°F / ${60 + i}°F`;
    document.getElementById("weeklyForecast").appendChild(card);
  }
}

function showDetails(hour) {
  const details = `
    <h3>Details for ${hour}:00</h3>
    <ul>
      <li>Temperature: ${65 + hour % 5}°F</li>
      <li>Wind: ${5 + hour % 3} mph</li>
      <li>Humidity: ${50 + hour % 10}%</li>
      <li>Rain: ${hour % 4 === 0 ? "0.5 mm" : "0 mm"}</li>
      <li>Visibility: ${5 + hour % 2} mi</li>
      <li>UV Index: ${hour % 8}</li>
      <li>AQI: ${30 + hour * 2}</li>
      <li>PWI: ${(Math.random() * 5 + 5).toFixed(1)}</li>
    </ul>
  `;
  document.getElementById("detailsCard").innerHTML = details;
}
